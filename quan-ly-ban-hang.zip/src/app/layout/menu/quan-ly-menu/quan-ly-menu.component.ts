import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quan-ly-menu',
  templateUrl: './quan-ly-menu.component.html',
  styleUrls: ['./quan-ly-menu.component.scss']
})
export class QuanLyMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
