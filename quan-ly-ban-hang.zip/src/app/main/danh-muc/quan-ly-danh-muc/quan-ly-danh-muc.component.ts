import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quan-ly-danh-muc',
  templateUrl: './quan-ly-danh-muc.component.html',
  styleUrls: ['./quan-ly-danh-muc.component.scss']
})
export class QuanLyDanhMucComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
